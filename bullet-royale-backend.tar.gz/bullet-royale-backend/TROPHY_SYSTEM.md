# 🏆 Bullet Royale Trophy System

## Overview
Single arena leaderboard with win streak bonuses and rating-based rewards for Lichess bullet games.

---

## Trophy Calculation

### **Wins**
```
Base: 30 trophies
+ Rating Bonus: +5 per 100 rating difference (if opponent higher rated)
+ Streak Bonus:
  - 3-4 wins: +10
  - 5-7 wins: +20
  - 8+ wins: +30
```

**Example:**
- Beat 2000-rated player (you're 1800): `30 + 10 = 40 trophies`
- Beat 2400-rated player on 5-win streak: `30 + 20 + 20 = 70 trophies`
- Beat 2800-rated player on 8-win streak: `30 + 40 + 30 = 100 trophies`

### **Losses**
```
Fixed: -20 trophies (no scaling)
Streak: Reset to 0
```

### **Draws**
```
Base: 0 trophies
+ Streak Preservation: Streak not broken, not increased
+ Streak Bonus (3+ streak): +5 trophies
+ Rating Bonus: +2 per 100 rating difference (if opponent higher rated)
```

**Example:**
- Draw with 2000-rated (you're 1800), no streak: `0 + 4 = 4 trophies`
- Draw with 2200-rated, 5-win streak: `0 + 5 + 4 = 9 trophies`
- Draw with 1800-rated (equal), 3-win streak: `0 + 5 = 5 trophies`

---

## Game Requirements

- ✅ **Rated** bullet games only
- ✅ **Bullet** time control (under 3 minutes)
- ❌ Aborted games don't count
- ❌ Casual/unrated games don't count

---

## Win Streaks

### How Streaks Work:
- **Wins**: Increase streak by 1, add bonus trophies
- **Draws**: Preserve streak, don't increase it, still get small bonus
- **Losses**: Reset streak to 0

### Streak Milestones:
- 🔥 **3 wins**: First bonus tier (+10)
- 🔥🔥 **5 wins**: Second bonus tier (+20)
- 🔥🔥🔥 **8+ wins**: Maximum bonus tier (+30)

---

## Configuration (.env)

```env
TROPHY_WIN_BASE=30              # Base trophies for a win
TROPHY_LOSS_BASE=20             # Fixed trophies lost (no scaling)
RATING_BONUS_PER_100=5          # Bonus per 100 rating difference
```

### Adjust These Values:

**Make it easier:**
```env
TROPHY_WIN_BASE=40
TROPHY_LOSS_BASE=10
RATING_BONUS_PER_100=8
```

**Make it harder:**
```env
TROPHY_WIN_BASE=20
TROPHY_LOSS_BASE=30
RATING_BONUS_PER_100=3
```

---

## Leaderboard Display

Players see:
- **Rank** - Position on leaderboard
- **Current Trophies** - Total trophies this season
- **Current Streak** - Active win streak (if any)
- **Max Streak** - Best streak this season
- **W/D/L** - Wins, draws, losses
- **Rating** - Current Lichess rating

Top 3 players get special badges:
- 🥇 1st place
- 🥈 2nd place
- 🥉 3rd place

---

## Monthly Reset

On the 1st of each month:
- All trophies reset to 0
- All streaks reset to 0
- Rankings archived to "Hall of Fame"
- New season begins
- Max streak preserved in archives

---

## Strategy Tips

### To Maximize Trophies:
1. **Build streaks** - The 8-win bonus is huge (+30)
2. **Challenge higher-rated** - +5 per 100 rating
3. **Protect streaks on draws** - Draw vs higher rated maintains streak + trophies
4. **Avoid losses** - Fixed -20 penalty hurts

### Example Strategy:
- Start against similar-rated to build 3-win streak
- Then challenge higher-rated players for big bonuses
- If winning streak at risk, draw is better than loss

---

## Frequently Asked Questions

**Q: Do draws break my streak?**
A: No! Draws preserve your streak and you still get trophies if on a 3+ streak or opponent is higher rated.

**Q: Why did I only lose 20 trophies?**
A: Losses are fixed at -20 regardless of opponent rating.

**Q: How often do games sync?**
A: Automatically every 5 minutes, or click "Sync" button for instant update.

**Q: Can trophies go negative?**
A: No, minimum is 0 trophies.

**Q: What happens to my streaks at month end?**
A: Current streak resets, but max streak is saved in season archives.

---

## Advanced Trophy Math

### Maximum Possible Single Game:
```
8+ win streak vs 3000-rated opponent (you're 2000):
30 (base) + 50 (rating) + 30 (streak) = 110 trophies
```

### Worst Case Single Game:
```
Loss: -20 trophies (fixed)
```

### Draw Scenarios:
```
Best: 5-streak vs +400 rated = 0 + 5 + 8 = 13 trophies
Neutral: No streak vs equal = 0 trophies
```

---

## Technical Details

### Database Fields:
- `current_trophies` - Total trophies
- `current_win_streak` - Active streak
- `max_win_streak` - Season best
- `total_wins` - All wins
- `total_draws` - All draws
- `total_losses` - All losses

### Sync Process:
1. Fetch recent bullet games from Lichess API
2. Sort chronologically (oldest first)
3. Calculate trophies game-by-game
4. Update streak after each game
5. Save to database
6. Update leaderboard

---

Built for fair, exciting competition! 🏆⚡
