# 🏆 Bullet Royale - Complete Setup Tutorial (PKCE OAuth)

**Build a Lichess bullet leaderboard with trophy system and win streaks - 100% FREE hosting!**

**Time Required:** 40-50 minutes (even faster now!)  
**Difficulty:** Beginner-friendly (copy-paste ready)  
**Cost:** $0/month forever

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Part 1: Understand Lichess OAuth (2 min)](#part-1-understand-lichess-oauth)
3. [Part 2: Setup Database (10 min)](#part-2-setup-database)
4. [Part 3: Setup Backend Locally (10 min)](#part-3-setup-backend-locally)
5. [Part 4: Test Locally (5 min)](#part-4-test-locally)
6. [Part 5: Deploy Backend (15 min)](#part-5-deploy-backend)
7. [Part 6: Deploy Frontend (10 min)](#part-6-deploy-frontend)
8. [Part 7: Go Live! (5 min)](#part-7-go-live)
9. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before starting, make sure you have:

- ✅ **Lichess account** (create at https://lichess.org if you don't have one)
- ✅ **GitHub account** (sign up at https://github.com)
- ✅ **Node.js 18+** installed ([download here](https://nodejs.org))
- ✅ **Git** installed ([download here](https://git-scm.com))
- ✅ **Text editor** (VS Code recommended: https://code.visualstudio.com)

**Check your installations:**
```bash
node --version    # Should show v18 or higher
git --version     # Should show git version
```

---

## Part 1: Understand Lichess OAuth

**⏱️ Time: 2 minutes**

### Good News! 🎉

**You DON'T need to create a Lichess OAuth app anymore!**

Lichess now uses a simpler system:
- ✅ No app registration required
- ✅ No Client ID needed
- ✅ No Client Secret needed
- ✅ Just works with PKCE!

### How It Works:

1. Your app redirects users to Lichess
2. User authorizes your app
3. Lichess redirects back to your site
4. You get an access token
5. Done!

**That's it!** The code handles everything automatically.

### What You Need:

Just your **Redirect URI** (where Lichess sends users back):
- **Local**: `http://localhost:3001/auth/lichess/callback`
- **Production**: `https://your-app.onrender.com/auth/lichess/callback`

You'll configure this in the `.env` file later.

---

## Part 2: Setup Database

**⏱️ Time: 10 minutes**

### Step 2.1: Create Supabase Account

1. **Go to Supabase**: https://supabase.com

2. **Sign up**: Click "Start your project" → Sign in with GitHub

3. **Create Organization**: 
   - Name: `bullet-royale` (or anything you like)
   - Click "Create organization"

### Step 2.2: Create Project

1. **Click "New Project"**

2. **Fill in details:**
   ```
   Name:              bullet-royale
   Database Password: [Create a strong password - SAVE THIS!]
   Region:            [Choose closest to you]
   Pricing Plan:      Free
   ```

3. **Click "Create new project"**

4. **Wait 2-3 minutes** for project to initialize (grab a coffee ☕)

### Step 2.3: Get Database URL

1. **Once project is ready**, click "Project Settings" (gear icon, bottom left)

2. **Click "Database" in left sidebar**

3. **Scroll down to "Connection string"**

4. **Select "URI"** tab

5. **Copy the connection string** - looks like:
   ```
   postgresql://postgres:[YOUR-PASSWORD]@db.abcdefghijklm.supabase.co:5432/postgres
   ```

6. **Important:** Replace `[YOUR-PASSWORD]` with the password you created in Step 2.2

7. **Save this URL somewhere safe!**

### Step 2.4: Create Database Tables

1. **Click "SQL Editor"** in left sidebar (looks like `</>`)

2. **Click "New Query"**

3. **Open the `schema.sql` file** from your downloaded files

4. **Copy ALL the SQL code** (from the very first line to the last line)

5. **Paste it into the Supabase SQL Editor**

6. **Click "Run"** (bottom right) or press `Ctrl+Enter`

7. **You should see:** "Success. No rows returned"

8. **Verify tables were created:**
   - Click "Table Editor" in left sidebar
   - You should see: `users`, `games`, `seasons`, `season_rankings`

**Your database is ready! ✅**

---

## Part 3: Setup Backend Locally

**⏱️ Time: 10 minutes**

### Step 3.1: Download and Extract Files

1. **Download all project files** (from wherever you saved them)

2. **Extract to a folder**, for example:
   ```
   C:\Users\YourName\bullet-royale-backend\
   or
   ~/bullet-royale-backend/
   ```

### Step 3.2: Open in Terminal/Command Prompt

**Windows:**
1. Open folder in File Explorer
2. Hold `Shift` + Right-click in empty space
3. Click "Open PowerShell window here"

**Mac/Linux:**
1. Open Terminal
2. Navigate to folder:
   ```bash
   cd ~/bullet-royale-backend
   ```

### Step 3.3: Install Dependencies

Run this command:
```bash
npm install
```

You should see:
```
added 150 packages in 15s
```

**If you get an error**, make sure Node.js is installed:
```bash
node --version
```

### Step 3.4: Create .env File

1. **Copy the example file:**

   **Windows:**
   ```bash
   copy .env.example .env
   ```

   **Mac/Linux:**
   ```bash
   cp .env.example .env
   ```

2. **Open `.env` file in your text editor** (right-click → Open with → VS Code)

3. **Fill in your credentials:**

   ```env
   # Lichess OAuth (OPTIONAL - defaults to your domain)
   LICHESS_CLIENT_ID=bullet-royale
   LICHESS_REDIRECT_URI=http://localhost:3001/auth/lichess/callback

   # Discord OAuth (OPTIONAL - skip for now)
   DISCORD_CLIENT_ID=
   DISCORD_CLIENT_SECRET=
   DISCORD_REDIRECT_URI=

   # Database (from Part 2 - Step 2.3)
   DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@db.xxxxx.supabase.co:5432/postgres

   # Session Secret (generate random string)
   SESSION_SECRET=my-super-secret-random-string-change-this-to-something-random

   # Server Configuration
   PORT=3001
   NODE_ENV=development
   FRONTEND_URL=http://localhost:3000

   # Trophy System Configuration
   TROPHY_WIN_BASE=30
   TROPHY_LOSS_BASE=20
   RATING_BONUS_PER_100=5
   SYNC_INTERVAL_MINUTES=5
   ```

4. **Important replacements:**
   - `LICHESS_CLIENT_ID` is optional (can use any name like "bullet-royale")
   - `LICHESS_REDIRECT_URI` must match exactly for local/production
   - Replace `DATABASE_URL` with YOUR database URL from Part 2
   - Change `SESSION_SECRET` to any random string (30+ characters)

5. **Save the file** (`Ctrl+S`)

### Step 3.5: Start the Backend Server

Run:
```bash
npm start
```

You should see:
```
╔═══════════════════════════════════════════════════╗
║       🏆 BULLET ROYALE API SERVER 🏆            ║
╚═══════════════════════════════════════════════════╝

✅ Connected to PostgreSQL database
Server running on port 3001
Environment: development

Ready to accept connections! ⚡
```

**Keep this terminal window open!** The server needs to keep running.

---

## Part 4: Test Locally

**⏱️ Time: 5 minutes**

### Step 4.1: Open the Frontend

1. **Open a NEW terminal/command prompt** (don't close the backend one!)

2. **Navigate to the `public` folder:**
   ```bash
   cd bullet-royale-backend/public
   ```

3. **Open `index.html` in your browser:**
   
   **Option A - Double-click:**
   - Find `index.html` in File Explorer/Finder
   - Double-click to open in browser

   **Option B - Use a local server (recommended):**
   
   If you have Python installed:
   ```bash
   # Python 3
   python -m http.server 3000
   
   # Python 2
   python -m SimpleHTTPServer 3000
   ```
   
   Then open: http://localhost:3000

   **Option C - VS Code Live Server:**
   - Install "Live Server" extension in VS Code
   - Right-click `index.html` → "Open with Live Server"

### Step 4.2: Test OAuth Connection

1. **You should see the website** with "BULLET ROYALE" title

2. **Click "♞ CONNECT LICHESS TO PLAY"**

3. **You'll be redirected to Lichess**

4. **Click "Authorize"** on the Lichess page

5. **You'll be redirected back to your site**

6. **You should see an alert:** "Welcome, YOUR_USERNAME! Your games are being synced."

7. **Your username and stats should appear** at the top of the page

### Step 4.3: Verify It's Working

Check the backend terminal - you should see:
```
✅ New user created: YOUR_USERNAME
✅ YOUR_USERNAME: 10 games, +245 trophies 🔥 3 streak
```

**Congratulations! Your local setup works! 🎉**

---

## Part 5: Deploy Backend

**⏱️ Time: 15 minutes**

Now let's make it live on the internet!

### Step 5.1: Create GitHub Repository

1. **Go to GitHub**: https://github.com

2. **Click the "+" icon** (top right) → "New repository"

3. **Fill in details:**
   ```
   Repository name:  bullet-royale-backend
   Description:      Lichess bullet trophy leaderboard
   Visibility:       Public
   ```

4. **DON'T check** "Add README" (we already have files)

5. **Click "Create repository"**

### Step 5.2: Push Code to GitHub

1. **In your terminal** (in the `bullet-royale-backend` folder):

   ```bash
   # Initialize git (if not already done)
   git init
   
   # Add all files
   git add .
   
   # Commit
   git commit -m "Initial commit - Bullet Royale backend"
   
   # Add GitHub as remote
   git remote add origin https://github.com/YOUR_USERNAME/bullet-royale-backend.git
   
   # Push to GitHub
   git branch -M main
   git push -u origin main
   ```

2. **Replace `YOUR_USERNAME`** with your actual GitHub username

3. **You might be asked to login** - use your GitHub credentials

4. **Refresh your GitHub page** - you should see all your files!

### Step 5.3: Deploy to Render

1. **Go to Render**: https://render.com

2. **Click "Get Started"** → "Sign in with GitHub"

3. **Authorize Render** to access your repositories

4. **Click "New +"** (top right) → "Web Service"

5. **Find your repository:**
   - You should see `bullet-royale-backend`
   - Click "Connect"

6. **Configure the service:**
   ```
   Name:              bullet-royale
   Region:            [Choose closest to you]
   Branch:            main
   Runtime:           Node
   Build Command:     npm install
   Start Command:     npm start
   Instance Type:     Free
   ```

7. **Click "Advanced"** button

8. **Add Environment Variables** - click "Add Environment Variable" for each:

   ```
   LICHESS_CLIENT_ID          = bullet-royale
   LICHESS_REDIRECT_URI       = https://YOUR-APP-NAME.onrender.com/auth/lichess/callback
   DATABASE_URL               = [Your Supabase database URL]
   SESSION_SECRET             = [Random string - same as local]
   NODE_ENV                   = production
   FRONTEND_URL               = https://YOUR-GITHUB-USERNAME.github.io/bullet-royale-frontend
   TROPHY_WIN_BASE            = 30
   TROPHY_LOSS_BASE           = 20
   RATING_BONUS_PER_100       = 5
   SYNC_INTERVAL_MINUTES      = 5
   ```

   **Important:** 
   - For `LICHESS_REDIRECT_URI` and `FRONTEND_URL`, we'll update these in the next steps
   - For now, just put placeholder values
   - `LICHESS_CLIENT_ID` can be any name you want!

9. **Click "Create Web Service"**

10. **Wait 3-5 minutes** for deployment (you'll see build logs)

11. **Once deployed**, you'll see: "Your service is live 🎉"

12. **Copy your Render URL:**
    - It will be something like: `https://bullet-royale-abc123.onrender.com`
    - Save this URL!

### Step 5.4: Update Render Environment Variables

1. **In Render dashboard**, click your service

2. **Click "Environment"** in left sidebar

3. **Update these two variables:**
   ```
   LICHESS_REDIRECT_URI = https://bullet-royale-abc123.onrender.com/auth/lichess/callback
   FRONTEND_URL         = [We'll update this after deploying frontend]
   ```

4. **Save changes** - your app will automatically redeploy

**Your backend is now live! ✅**

Test it: Visit `https://YOUR-APP.onrender.com/health`  
You should see: `{"status":"ok","timestamp":"2024-..."}`

---

## Part 6: Deploy Frontend

**⏱️ Time: 10 minutes**

### Step 6.1: Update Frontend API URL

1. **Open `public/index.html`** in your text editor

2. **Find this line** (around line 467):
   ```javascript
   const API_URL = 'http://localhost:3001';
   ```

3. **Change it to your Render URL:**
   ```javascript
   const API_URL = 'https://bullet-royale-abc123.onrender.com';
   ```

4. **Save the file**

### Step 6.2: Create Frontend Repository

1. **Create a NEW folder** for frontend:
   ```bash
   mkdir bullet-royale-frontend
   cd bullet-royale-frontend
   ```

2. **Copy the index.html file:**
   ```bash
   # Windows
   copy ..\bullet-royale-backend\public\index.html index.html
   
   # Mac/Linux
   cp ../bullet-royale-backend/public/index.html index.html
   ```

3. **Initialize git:**
   ```bash
   git init
   git add index.html
   git commit -m "Initial commit - frontend"
   ```

4. **Create GitHub repository:**
   - Go to https://github.com/new
   - Name: `bullet-royale-frontend`
   - Public
   - Create repository

5. **Push to GitHub:**
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/bullet-royale-frontend.git
   git branch -M main
   git push -u origin main
   ```

### Step 6.3: Enable GitHub Pages

1. **Go to your repository** on GitHub

2. **Click "Settings"** tab

3. **Click "Pages"** in left sidebar

4. **Under "Source":**
   - Branch: `main`
   - Folder: `/ (root)`

5. **Click "Save"**

6. **Wait 1-2 minutes**

7. **Refresh the page** - you'll see:
   ```
   Your site is live at https://YOUR_USERNAME.github.io/bullet-royale-frontend/
   ```

8. **Copy this URL!**

### Step 6.4: Update Backend with Frontend URL

1. **Go back to Render dashboard**

2. **Click your service** → "Environment"

3. **Update `FRONTEND_URL`:**
   ```
   FRONTEND_URL = https://YOUR_USERNAME.github.io/bullet-royale-frontend
   ```

4. **Save** - service will redeploy

---

## Part 7: Go Live!

**⏱️ Time: 5 minutes**

### Step 7.1: Test Production Site

1. **Visit your GitHub Pages URL:**
   ```
   https://YOUR_USERNAME.github.io/bullet-royale-frontend/
   ```

2. **You should see the Bullet Royale site!**

3. **Click "♞ CONNECT LICHESS TO PLAY"**

4. **Authorize on Lichess**

5. **You should be redirected back** and see your profile!

### Step 7.2: Verify Everything Works

✅ **Check these:**
- [ ] Can connect with Lichess
- [ ] Your username appears
- [ ] Leaderboard loads
- [ ] "Sync Games" button works
- [ ] Season reset timer shows

### Step 7.3: Share Your Site!

Your leaderboard is now **LIVE**! 🎉

Share it with:
- Chess club members
- Lichess forums
- Reddit r/chess
- Discord servers
- Twitter/X

**Your URLs:**
- 🌐 **Website**: `https://YOUR_USERNAME.github.io/bullet-royale-frontend/`
- 🔧 **Backend**: `https://YOUR-APP.onrender.com`
- 💾 **Database**: Supabase dashboard

---

## 🎮 How Players Use It

1. **Visit your site**
2. **Click "Connect Lichess"**
3. **Authorize**
4. **Play bullet games on Lichess** (rated only!)
5. **Games sync automatically every 5 minutes**
6. **Watch trophies and streaks grow!**
7. **Compete for #1 on leaderboard**
8. **Monthly reset** - new season begins!

---

## 🏆 Trophy System Quick Reference

**Win:**
- Base: 30 trophies
- +5 per 100 rating (if opponent higher)
- 3-4 streak: +10
- 5-7 streak: +20
- 8+ streak: +30

**Loss:**
- Fixed: -20 trophies
- Breaks streak

**Draw:**
- 0 trophies normally
- Preserves streak
- +5 if on 3+ streak
- +2 per 100 rating (if opponent higher)

---

## Troubleshooting

### "Cannot GET /" on Render

**Problem:** Backend deployed but shows error  
**Solution:**
1. Check Render logs (click service → Logs tab)
2. Verify all environment variables are set
3. Make sure `DATABASE_URL` is correct

### "OAuth failed"

**Problem:** Can't connect Lichess  
**Solution:**
1. Verify `LICHESS_REDIRECT_URI` is exactly correct (http vs https!)
2. Make sure backend server is running
3. Check browser console for errors
4. `LICHESS_CLIENT_ID` can be any name - doesn't need to match anything

### "Leaderboard not loading"

**Problem:** Frontend shows spinning loader forever  
**Solution:**
1. Open browser console (F12)
2. Check for CORS errors
3. Verify `API_URL` in index.html is correct
4. Make sure backend is running (visit /health endpoint)

### "Games not syncing"

**Problem:** Trophies don't update  
**Solution:**
1. Check Render logs for sync errors
2. Verify you're playing RATED bullet games
3. Click "Sync Games" button manually
4. Wait 5 minutes for auto-sync

### Render app sleeping

**Problem:** First request takes 30 seconds  
**Solution:**
- This is normal on free tier
- App spins down after 15min inactivity
- First request "wakes it up"
- Subsequent requests are instant
- Consider upgrading to Render Starter ($7/mo) if needed

### Database connection failed

**Problem:** Can't connect to Supabase  
**Solution:**
1. Check `DATABASE_URL` has correct password
2. Verify Supabase project is active
3. Check connection pooling settings
4. Try resetting database password in Supabase

---

## 🎉 Success Checklist

You're done when:

- [x] Backend deployed to Render
- [x] Frontend deployed to GitHub Pages
- [x] Can connect with Lichess OAuth
- [x] Leaderboard shows players
- [x] Games sync automatically
- [x] Trophy calculations work
- [x] Win streaks display
- [x] Monthly timer counts down
- [x] Site is accessible to anyone

---

## 📈 Next Steps

### Customize Your Leaderboard

1. **Change trophy values** (edit `.env` on Render):
   ```
   TROPHY_WIN_BASE=40
   TROPHY_LOSS_BASE=10
   ```

2. **Adjust colors/fonts** (edit `index.html`)

3. **Add Discord OAuth** (optional)

4. **Create Hall of Fame page** for past winners

5. **Add email notifications** for season resets

### Monitor Your Site

- **Render Dashboard**: Check logs, uptime
- **Supabase Dashboard**: View database, run queries
- **GitHub**: Track code changes

### Promote Your Leaderboard

- Post on chess forums
- Share with local chess clubs
- Create tournament events
- Stream on Twitch while competing
- Tweet screenshots of top players

---

## 💰 Costs

**Free Forever:**
- Render: 750 hours/month (enough for 24/7)
- Supabase: 500MB database
- GitHub Pages: Unlimited

**Only upgrade if:**
- 100+ active users (Render needs more resources)
- Database > 500MB (Supabase Pro: $25/mo)
- Want faster response times (Render Starter: $7/mo)

For most chess clubs and small communities: **$0/month is plenty!**

---

## 🎓 What You Learned

You now know how to:
- ✅ Set up OAuth 2.0 with PKCE
- ✅ Build a Node.js/Express backend
- ✅ Use PostgreSQL database
- ✅ Deploy to cloud platforms
- ✅ Integrate with Lichess API
- ✅ Create real-time leaderboards
- ✅ Implement game mechanics (trophies, streaks)
- ✅ Build production web apps

**These skills transfer to other projects!** 🚀

---

## 🤝 Get Help

**Issues? Questions?**

1. Check [TROUBLESHOOTING section](#troubleshooting) above
2. Review [TROPHY_SYSTEM.md](./TROPHY_SYSTEM.md) for rules
3. Read [OAUTH_PKCE_GUIDE.md](./OAUTH_PKCE_GUIDE.md) for OAuth details
4. Check Render logs for backend errors
5. Open browser console (F12) for frontend errors

**Still stuck?**
- Create GitHub Issue with error details
- Include: what you tried, error messages, screenshots

---

## 🎊 Congratulations!

You've built and deployed a **production-ready chess leaderboard**! 

Players can now:
- 🏆 Compete for trophies
- 🔥 Build win streaks  
- 📊 Track their stats
- 🎯 Climb the rankings
- 🏅 Win monthly seasons

**Your chess community just got a lot more competitive!** ⚡

---

**Built with ❤️ for chess players everywhere**

Ready to dominate the leaderboard? **Let the games begin!** ♟️
