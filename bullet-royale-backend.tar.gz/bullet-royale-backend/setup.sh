#!/bin/bash

echo "╔═══════════════════════════════════════════════════╗"
echo "║     🏆 BULLET ROYALE QUICK SETUP 🏆             ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "Please install Node.js from https://nodejs.org"
    exit 1
fi

echo "✅ Node.js version: $(node -v)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚠️  No .env file found. Creating from template..."
    cp .env.example .env
    echo "✅ Created .env file"
    echo ""
    echo "🔧 IMPORTANT: Edit .env file with your credentials:"
    echo "   1. Lichess OAuth (from https://lichess.org/account/oauth/app/create)"
    echo "   2. Database URL (from Supabase)"
    echo "   3. Session secret (any random string)"
    echo ""
    echo "Press any key to open .env file..."
    read -n 1
    
    # Try to open .env in default editor
    if command -v code &> /dev/null; then
        code .env
    elif command -v nano &> /dev/null; then
        nano .env
    elif command -v vim &> /dev/null; then
        vim .env
    else
        echo "Please manually edit .env file"
    fi
else
    echo "✅ .env file already exists"
fi

echo ""
echo "╔═══════════════════════════════════════════════════╗"
echo "║              SETUP COMPLETE! 🎉                  ║"
echo "╚═══════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "1. Make sure .env is configured with your credentials"
echo "2. Run 'npm start' to start the server"
echo "3. Open public/index.html in your browser"
echo ""
echo "For detailed setup instructions, see README.md"
echo ""
