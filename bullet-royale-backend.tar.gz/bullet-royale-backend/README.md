# 🏆 Bullet Royale - Complete Setup Guide

A Clash Royale-style trophy leaderboard system for Lichess bullet games with monthly resets.

## 🎯 What You'll Build

- **Real-time leaderboard** syncing with Lichess bullet games
- **Trophy system** with 4 arenas (Legendary, Royal, Builder, Training)
- **Monthly resets** with season archives
- **OAuth login** for Lichess (+ optional Discord)
- **Automatic game syncing** every 5 minutes
- **100% FREE hosting** using free-tier services

---

## 📋 Prerequisites

- Node.js 18+ installed ([download](https://nodejs.org))
- Git installed ([download](https://git-scm.com))
- GitHub account (for hosting)
- Lichess account (for OAuth app)

---

## 🚀 Step-by-Step Setup

### **STEP 1: No Lichess OAuth App Needed! 🎉**

**Good news!** Lichess now uses PKCE OAuth which doesn't require app registration.

You just need to configure your redirect URI in the `.env` file later. That's it!

**How it works:**
- Your domain/localhost is used as the client_id
- No pre-registration needed
- Just works automatically!

---

### **STEP 2: Setup Database (Supabase - FREE)**

1. Go to https://supabase.com and create account
2. Click **New Project**
   - **Project name**: bullet-royale
   - **Database password**: (choose a strong password)
   - **Region**: (choose closest to you)
3. Wait for project to be created (~2 minutes)
4. Go to **Settings** → **Database** → Copy the **Connection string** (it looks like: `postgresql://postgres:[YOUR-PASSWORD]@db.xxx.supabase.co:5432/postgres`)
5. Go to **SQL Editor** → Click **New Query**
6. Copy the entire contents of `schema.sql` and paste it
7. Click **Run** to create all tables

---

### **STEP 3: Setup Backend Locally**

```bash
# Navigate to backend folder
cd bullet-royale-backend

# Install dependencies
npm install

# Create .env file (copy from example)
cp .env.example .env

# Edit .env file with your credentials
# Use your favorite text editor (nano, vim, VS Code, etc.)
nano .env
```

Fill in your `.env` file with:

```env
# Lichess OAuth (PKCE - no registration needed!)
LICHESS_CLIENT_ID=bullet-royale
LICHESS_REDIRECT_URI=http://localhost:3001/auth/lichess/callback

# Supabase Database (from Step 2)
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@db.xxx.supabase.co:5432/postgres

# Generate a random string for session security
SESSION_SECRET=generate_a_random_string_here_at_least_32_characters

# Local development settings
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:3000

# Trophy settings (optional - use defaults)
TROPHY_WIN_BASE=30
TROPHY_LOSS_BASE=15
SYNC_INTERVAL_MINUTES=5
```

**Start the backend:**

```bash
npm start
```

You should see:
```
╔═══════════════════════════════════════════════════╗
║       🏆 BULLET ROYALE API SERVER 🏆            ║
╚═══════════════════════════════════════════════════╝

Server running on port 3001
Ready to accept connections! ⚡
```

---

### **STEP 4: Test Locally**

1. Open `public/index.html` in your browser (double-click or use Live Server in VS Code)
2. Click **"CONNECT LICHESS TO PLAY"**
3. You'll be redirected to Lichess to authorize
4. After authorization, you'll be redirected back and your account will be synced!
5. Your recent bullet games will be processed and trophies calculated

---

### **STEP 5: Deploy to Production (Render - FREE)**

Render offers completely FREE hosting with no credit card required!

#### **5.1: Deploy Backend to Render**

1. Create a GitHub repository for your code:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/bullet-royale.git
   git push -u origin main
   ```

2. Go to https://render.com and sign up with GitHub

3. Click **New** → **Web Service**

4. Connect your GitHub repository

5. Configure the service:
   - **Name:** bullet-royale
   - **Environment:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free

6. Click **Advanced** and add environment variables:
   - `LICHESS_CLIENT_ID` = bullet-royale (any name works!)
   - `LICHESS_REDIRECT_URI` = `https://YOUR_APP.onrender.com/auth/lichess/callback`
   - `DATABASE_URL` = your_supabase_url
   - `SESSION_SECRET` = random_string
   - `NODE_ENV` = `production`
   - `FRONTEND_URL` = (we'll update this in Step 5.2)

7. Click **Create Web Service**

8. Wait 3-5 minutes for deployment

9. Copy your Render URL (like `https://bullet-royale.onrender.com`)

**Note:** Free tier spins down after 15min of inactivity. First request after sleep takes ~30 seconds to wake up.

#### **5.2: Deploy Frontend to GitHub Pages (FREE)**

1. Update the `API_URL` in `public/index.html`:
   ```javascript
   const API_URL = 'https://YOUR_APP.railway.app'; // Your Railway URL
   ```

2. Create a new GitHub repository for frontend:
   ```bash
   cd public
   git init
   git add index.html
   git commit -m "Initial frontend"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/bullet-royale-frontend.git
   git push -u origin main
   ```

3. In GitHub repository settings:
   - Go to **Settings** → **Pages**
   - **Source**: Deploy from a branch
   - **Branch**: main / (root)
   - Click **Save**

4. Wait 1-2 minutes, then your site will be live at:
   `https://YOUR_USERNAME.github.io/bullet-royale-frontend/`

5. Update Render environment variable:
   - Go back to Render dashboard
   - Update `FRONTEND_URL` to your GitHub Pages URL
   - Service will auto-redeploy

#### **5.3: Update Lichess OAuth App**

1. Go back to https://lichess.org/account/oauth/app
2. Edit your app
3. Add production redirect URI:
   `https://YOUR_APP.onrender.com/auth/lichess/callback`
4. Save

---

### **STEP 6: Testing Production**

1. Visit your GitHub Pages URL
2. Click "Connect Lichess"
3. Authorize the app
4. You should be redirected back and see your stats!

---

## 🎮 How It Works

### **Trophy Calculation**

- **Win**: Base 30 trophies + bonus for beating higher-rated players
- **Loss**: Lose 15 trophies + extra penalty for losing to lower-rated
- **Draw**: Small trophy adjustment based on rating difference

### **Arenas**

- 🏆 **Legendary Arena**: 4000+ trophies (gold)
- 👑 **Royal Arena**: 3000-3999 trophies (silver)
- 🔨 **Builder Arena**: 2000-2999 trophies (bronze)
- ⚔️ **Training Arena**: 0-1999 trophies (brown)

### **Monthly Reset**

- Happens automatically on the 1st of each month at midnight UTC
- All trophies reset to 0
- Previous season rankings are archived
- You can view past season winners

### **Game Syncing**

- Automatic sync every 5 minutes for all users
- Manual "Sync Games" button for instant updates
- Only processes new bullet games since last sync
- Prevents duplicate game processing

---

## 🛠️ Customization

### **Change Trophy Values**

Edit `.env`:
```env
TROPHY_WIN_BASE=50     # Default: 30
TROPHY_LOSS_BASE=20    # Default: 15
```

### **Change Sync Frequency**

Edit `.env`:
```env
SYNC_INTERVAL_MINUTES=10  # Default: 5
```

### **Change Arena Thresholds**

Edit `schema.sql` view definition:
```sql
CASE 
    WHEN current_trophies >= 5000 THEN 'Legendary Arena'  -- Changed from 4000
    WHEN current_trophies >= 3500 THEN 'Royal Arena'      -- Changed from 3000
    ...
```

---

## 📊 Database Tables

- **users**: Player accounts and stats
- **games**: Individual game records
- **seasons**: Season tracking
- **season_rankings**: Historical leaderboards
- **leaderboard** (view): Real-time rankings

---

## 🔧 Troubleshooting

### **"Database connection failed"**
- Check your `DATABASE_URL` in `.env`
- Ensure Supabase project is running
- Verify password is correct in connection string

### **"OAuth failed"**
- Check `LICHESS_CLIENT_ID` in `.env`
- Verify redirect URI matches exactly (http vs https matters!)
- Make sure you authorized the app on Lichess
- **Note**: No client secret needed with new PKCE flow!

### **"Games not syncing"**
- Check server logs for errors
- Verify Lichess username is correct
- Ensure you've played rated bullet games recently
- Try manual sync button

### **"Leaderboard not loading"**
- Check browser console (F12) for errors
- Verify `API_URL` is correct in frontend
- Check CORS settings in backend
- Ensure Railway app is deployed and running

---

## 📈 Monitoring & Maintenance

### **View Logs (Render)**
- Go to your Render dashboard
- Click your service → **Logs**
- See real-time sync activity and errors

### **Check Database (Supabase)**
- Go to Supabase dashboard
- **Table Editor** to view data
- **SQL Editor** to run queries

### **Backup Database**
```sql
-- Run in Supabase SQL Editor to download data
SELECT * FROM users;
SELECT * FROM games;
SELECT * FROM season_rankings;
```

---

## 🎉 You're Done!

Your Bullet Royale leaderboard is now live! Players can:
1. Connect their Lichess account
2. Play bullet games on Lichess
3. Watch their trophies change automatically
4. Compete for the top spot each month

---

## 💰 Cost Breakdown (All FREE!)

- **Railway Backend**: $5/month credit (FREE tier)
- **Supabase Database**: 500MB database (FREE tier)
- **GitHub Pages**: Unlimited bandwidth (FREE)
- **Lichess API**: Completely free
- **Total Cost**: $0/month 🎉

---

## 🚀 Next Steps

- Add Discord OAuth for community features
- Create a Hall of Fame page for past winners
- Add player profiles with game history
- Email notifications for season resets
- Mobile app version
- Tournament mode
- Team competitions

---

## 📝 License

MIT License - Feel free to modify and use!

---

## 🤝 Contributing

Found a bug? Have an idea? Open an issue or submit a PR!

---

**Built with ❤️ for the chess community**
