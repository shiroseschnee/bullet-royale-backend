# 🔐 Lichess OAuth Update - PKCE Flow

## What Changed?

Lichess now uses **PKCE (Proof Key for Code Exchange)** for OAuth, which is more secure and doesn't require a client secret!

---

## Old Flow (Deprecated)
```
1. Client ID + Client Secret
2. Redirect to Lichess
3. Get code back
4. Exchange code + secret for token
```

## New Flow (PKCE)
```
1. Client ID only (no secret!)
2. Generate code_verifier + code_challenge
3. Redirect to Lichess with challenge
4. Get code back
5. Exchange code + verifier for token
```

---

## What This Means For You

### ✅ **Advantages:**
- **More Secure**: No secret to leak
- **Simpler**: One less credential to manage
- **Better for SPAs**: Can be used directly in frontend (though we use backend)

### 🔧 **What Changed in Code:**

**server.js:**
- Added PKCE generation functions
- Generate `code_verifier` and `code_challenge` before redirect
- Store verifier temporarily (10 min expiry)
- Pass verifier to token exchange

**lichess.js:**
- Updated `getAccessToken()` to accept `code_verifier`
- Removed `client_secret` from token request
- Added `code_verifier` parameter

**.env:**
- Removed `LICHESS_CLIENT_SECRET` (not needed!)
- Only need `LICHESS_CLIENT_ID`

---

## Setup Instructions

### Step 1: Create Lichess OAuth App
1. Go to https://lichess.org/account/oauth/app/create
2. Fill in details:
   - **Name**: Your app name
   - **Redirect URI**: `http://localhost:3001/auth/lichess/callback`
3. **Important**: You'll only get a Client ID (no secret!)

### Step 2: Update .env
```env
LICHESS_CLIENT_ID=your_client_id_here
LICHESS_REDIRECT_URI=http://localhost:3001/auth/lichess/callback
# No LICHESS_CLIENT_SECRET needed!
```

### Step 3: That's It!
The PKCE flow is handled automatically by the backend.

---

## How PKCE Works (Technical)

### 1. Generate Code Verifier
```javascript
const codeVerifier = crypto.randomBytes(32).toString('base64url');
// Example: "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"
```

### 2. Generate Code Challenge
```javascript
const codeChallenge = crypto
  .createHash('sha256')
  .update(codeVerifier)
  .digest('base64url');
// Example: "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"
```

### 3. Authorization Request
```
https://lichess.org/oauth?
  response_type=code&
  client_id=YOUR_CLIENT_ID&
  redirect_uri=http://localhost:3001/auth/lichess/callback&
  code_challenge_method=S256&
  code_challenge=E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM&
  state=random_state_value&
  scope=preference:read
```

### 4. Token Exchange
```javascript
POST https://lichess.org/api/token
{
  grant_type: "authorization_code",
  code: "received_code",
  code_verifier: "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk",
  redirect_uri: "http://localhost:3001/auth/lichess/callback",
  client_id: "YOUR_CLIENT_ID"
}
```

Lichess verifies:
```javascript
SHA256(code_verifier) === code_challenge ? ✅ : ❌
```

---

## Security Benefits

### Why PKCE is Better:

1. **No Secret to Steal**: Client secret can't be leaked
2. **Single-Use Codes**: Each authorization uses unique verifier
3. **Man-in-the-Middle Protection**: Even if code is intercepted, verifier is needed
4. **State Validation**: Prevents CSRF attacks

### Attack Prevention:

**Without PKCE:**
```
Attacker intercepts code → Uses code + stolen secret → Gets token ❌
```

**With PKCE:**
```
Attacker intercepts code → Missing verifier → Can't get token ✅
```

---

## Troubleshooting

### "invalid_grant" error
- Code verifier doesn't match challenge
- Code expired (10 min timeout)
- State parameter mismatch

**Solution:** Clear cookies and try again

### "invalid_client" error
- Wrong Client ID
- App not approved on Lichess

**Solution:** Check Client ID in .env

### "invalid_request" error
- Missing required parameters
- Wrong redirect URI

**Solution:** Verify all OAuth parameters match

---

## Production Considerations

### In Development:
- Verifiers stored in memory (Map)
- OK for testing

### In Production:
- Use Redis or similar for verifier storage
- Implement cleanup for expired verifiers
- Add rate limiting

**Example with Redis:**
```javascript
// Store verifier
await redis.setex(`pkce:${state}`, 600, codeVerifier);

// Retrieve verifier
const verifier = await redis.get(`pkce:${state}`);
await redis.del(`pkce:${state}`);
```

---

## Migration Checklist

If updating from old OAuth:

- [ ] Remove `LICHESS_CLIENT_SECRET` from .env
- [ ] Update `server.js` with PKCE code
- [ ] Update `lichess.js` token exchange
- [ ] Test OAuth flow locally
- [ ] Update production environment variables
- [ ] Remove old secret from Render/Railway

---

## References

- [OAuth 2.0 PKCE RFC](https://tools.ietf.org/html/rfc7636)
- [Lichess OAuth Docs](https://lichess.org/api#section/Authentication)
- [PKCE Explained](https://oauth.net/2/pkce/)

---

**Bottom Line:** PKCE is simpler, more secure, and the modern standard. No client secret = fewer security concerns! 🔒✨
